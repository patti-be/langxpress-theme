<?php

use Scout\Wrapper;

?>


<?php get_header(); ?>

<?php include Wrapper\template_path(); ?>

<?php  //echo Wrapper\template_path(); ?>

<?php get_footer(); ?>

