<?php

/**
 * Page Builder - Spacer
 *
 *
 */
?>

<?php
if (get_sub_field('add_spacer')) : ?>
    <div style="padding-top: 5rem;"></div>
<?php endif;
